FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GEORGE WASHINGTON UNIVERSITY', '530196584', 'Education', '', 'Education organization with annual revenue of approximately $1912M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MDWISE MEDICAID NETWORK INC', '473192307', 'Health', '', 'Health organization with annual revenue of approximately $1907M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'COMMUNITY HEALTH CHOICE TEXAS INC', '814077507', 'Other', '', 'Other organization with annual revenue of approximately $1905M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'OUR LADY OF THE LAKE HOSPITAL INC', '720423651', 'Health', '', 'Health organization with annual revenue of approximately $1901M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MORGAN STANLEY GLOBAL IMPACT FUNDING TRUST INC', '527082731', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1884M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHILDRENS HOSPITAL COLORADO', '840166760', 'Health', '', 'Health organization with annual revenue of approximately $1884M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'NEIGHBORHOOD HEALTH PLAN OF RHODE ISLAND', '050477052', 'Health', '', 'Health organization with annual revenue of approximately $1883M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SUTTER HEALTH', '942788907', 'Health', '', 'Health organization with annual revenue of approximately $1882M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MERCY HOSPITALS EAST COMMUNITIES', '430653493', 'Health', '', 'Health organization with annual revenue of approximately $1879M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GEISINGER MEDICAL CENTER', '240795959', 'Health', '', 'Health organization with annual revenue of approximately $1878M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GRAND CANYON UNIVERSITY', '472507725', 'Education', '', 'Education organization with annual revenue of approximately $1870M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ADVENTIST HEALTH SYSTEM SUNBELT HEALTHCARE CORPORATION', '592170012', 'Health', '', 'Health organization with annual revenue of approximately $1862M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SHRINERS HOSPITALS FOR CHILDREN', '362193608', 'Health', '', 'Health organization with annual revenue of approximately $1843M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'HOAG MEMORIAL HOSPITAL PRESBYTERIAN', '951643327', 'Health', '', 'Health organization with annual revenue of approximately $1843M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'HAWAII PACIFIC HEALTH GROUP RETURN', '383835105', 'Other', '', 'Other organization with annual revenue of approximately $1838M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LOMA LINDA UNIVERSITY MEDICAL CENTER INC', '953522679', 'Health', '', 'Health organization with annual revenue of approximately $1837M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LESTER E COX MEDICAL CENTER', '440577118', 'Health', '', 'Health organization with annual revenue of approximately $1830M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PGA TOUR INC', '520999206', 'Other', '', 'Other organization with annual revenue of approximately $1828M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FRANCISCAN HEALTH SYSTEM', '910564491', 'Health', '', 'Health organization with annual revenue of approximately $1821M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BAYSTATE MEDICAL CENTER INC', '042790311', 'Health', '', 'Health organization with annual revenue of approximately $1815M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MDWISE INC', '351931354', 'Other', '', 'Other organization with annual revenue of approximately $1812M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LIBERTY UNIVERSITY INC', '540946734', 'Education', '', 'Education organization with annual revenue of approximately $1802M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THE ADMINISTRATORS OF THE TULANE EDUCATIONAL FUND', '720423889', 'Education', '', 'Education organization with annual revenue of approximately $1798M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BUILDING SERVICE 32BJ HEALTH FUND', '132928869', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1795M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SCOTT & WHITE MEMORIAL HOSPITAL', '741166904', 'Health', '', 'Health organization with annual revenue of approximately $1794M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'JOHN MUIR HEALTH', '941461843', 'Health', '', 'Health organization with annual revenue of approximately $1776M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PRISMA HEALTH-MIDLANDS', '582296052', 'Health', '', 'Health organization with annual revenue of approximately $1774M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GOTHIC CORPORATION', '561776668', 'Education', '', 'Education organization with annual revenue of approximately $1766M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MASS GENERAL BRIGHAM HEALTH PLAN INC', '042932021', 'Health', '', 'Health organization with annual revenue of approximately $1763M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MICHIGAN CATASTROPHIC CLAIMS ASSOCIATION U S', '382227794', 'Other', '', 'Other organization with annual revenue of approximately $1760M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'HOWARD HUGHES MEDICAL INSTITUTE', '590735717', 'Health', '', 'Health organization with annual revenue of approximately $1760M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SAINT FRANCIS HOSPITAL INC', '730700090', 'Health', '', 'Health organization with annual revenue of approximately $1760M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SHARP HEALTHCARE', '956077327', 'Health', '', 'Health organization with annual revenue of approximately $1758M'
FROM users WHERE email = 'test@example.com';
