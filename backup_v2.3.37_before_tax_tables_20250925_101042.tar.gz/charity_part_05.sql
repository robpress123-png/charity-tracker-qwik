FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BANKAMERICA GROUP BENEFITS PROGRAM TR', '957055654', 'Human Services', '', 'Human Services organization with annual revenue of approximately $2819M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LUCILE SALTER PACKARD CHILDRENS HOSPITAL AT STANFORD', '770003859', 'Health', '', 'Health organization with annual revenue of approximately $2778M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FROEDTERT THEDACARE HEALTH INC', '392014409', 'Health', '', 'Health organization with annual revenue of approximately $2769M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BAYLOR COLLEGE OF MEDICINE', '741613878', 'Education', '', 'Education organization with annual revenue of approximately $2756M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST LUKES REGIONAL MEDICAL CENTER', '820161600', 'Health', '', 'Health organization with annual revenue of approximately $2744M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FRESNO COMMUNITY HOSPITAL AND MEDICAL CENTER', '941156276', 'Health', '', 'Health organization with annual revenue of approximately $2742M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'TUFTS ASSOCIATED HEALTH MAINTENANCE ORGANIZATION INC', '042674079', 'Other', '', 'Other organization with annual revenue of approximately $2738M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY OF BRITISH COLUMBIA', '986001255', 'Education', '', 'Education organization with annual revenue of approximately $2716M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BOY SCOUTS OF AMERICA', '221576300', 'Human Services', '', 'Human Services organization with annual revenue of approximately $2702M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FROEDTERT MEMORIAL LUTHERAN HOSPITAL INC', '396105970', 'Health', '', 'Health organization with annual revenue of approximately $2686M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'HARTFORD HOSPITAL', '060646668', 'Health', '', 'Health organization with annual revenue of approximately $2659M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY HEALTH NETWORK', '986000971', 'Other', '', 'Other organization with annual revenue of approximately $2656M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SHANDS TEACHING HOSPITAL AND CLINICS INC', '591943502', 'Health', '', 'Health organization with annual revenue of approximately $2654M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BAPTIST HOSPITAL OF MIAMI INC', '590910342', 'Health', '', 'Health organization with annual revenue of approximately $2645M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SOUTHERN BAPTIST HOSPITAL OF FLORIDA INC', '590747311', 'Health', '', 'Health organization with annual revenue of approximately $2644M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THOMAS JEFFERSON UNIVERSITY HOSPITAL', '232829095', 'Health', '', 'Health organization with annual revenue of approximately $2643M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UC HEALTHCARE SYSTEM', '273850988', 'Health', '', 'Health organization with annual revenue of approximately $2631M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GAVI ALLIANCE', '980593375', 'International', '', 'International organization with annual revenue of approximately $2630M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'STATE CHARTERED CREDIT UNIONS INC', '560475645', 'Other', '', 'Other organization with annual revenue of approximately $2616M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BOSTON MEDICAL CENTER CORPORATION', '043314093', 'Health', '', 'Health organization with annual revenue of approximately $2600M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PRAIRIE MEADOWS RACE TRACK & CASINO INC', '421244913', 'Other', '', 'Other organization with annual revenue of approximately $2595M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UAW RETIREE MEDICAL BENEFITS TR', '900424876', 'Human Services', '', 'Human Services organization with annual revenue of approximately $2584M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'VANDERBILT UNIVERSITY', '620476822', 'Education', '', 'Education organization with annual revenue of approximately $2567M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'COMMONWEALTH CARE ALLIANCE INC', '043756900', 'Health', '', 'Health organization with annual revenue of approximately $2562M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHILDRENS HEALTHCARE OF ATLANTA INC', '900779996', 'Health', '', 'Health organization with annual revenue of approximately $2550M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WELLSTAR HEALTH SYSTEM INC', '581649541', 'Health', '', 'Health organization with annual revenue of approximately $2548M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CARESOURCE', '311703368', 'Health', '', 'Health organization with annual revenue of approximately $2546M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WELLS FARGO & COMPANY EMPLOYEE BENEFIT TRUST', '411340042', 'Other', '', 'Other organization with annual revenue of approximately $2546M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'HEALTH PARTNERS PLANS INC', '232379751', 'Other', '', 'Other organization with annual revenue of approximately $2533M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'AT&T VEBA TRUST', '431491162', 'Other', '', 'Other organization with annual revenue of approximately $2486M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CAREOREGON INC', '930933975', 'Health', '', 'Health organization with annual revenue of approximately $2483M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'TUFTS HEALTH PUBLIC PLANS INC', '800721489', 'Human Services', '', 'Human Services organization with annual revenue of approximately $2470M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'NORTHWELL HEALTHCARE INC', '112965586', 'Health', '', 'Health organization with annual revenue of approximately $2459M'
FROM users WHERE email = 'test@example.com';
