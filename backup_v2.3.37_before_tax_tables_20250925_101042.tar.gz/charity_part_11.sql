FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ALBERT EINSTEIN HEALTHCARE NETWORK', '465338502', 'Other', '', 'Other organization with annual revenue of approximately $1517M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST VINCENT HOSPITAL & HEALTH CARE', '350869066', 'Health', '', 'Health organization with annual revenue of approximately $1516M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'STATEN ISLAND UNIVERSITY HOSPITAL', '112868878', 'Health', '', 'Health organization with annual revenue of approximately $1512M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SOUTHERN NEW HAMPSHIRE UNIVERSITY', '020274509', 'Education', '', 'Education organization with annual revenue of approximately $1511M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST JOSEPH HEALTH NORTHERN CALIFORNIA LLC', '814791043', 'Health', '', 'Health organization with annual revenue of approximately $1504M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY HEALTH SYSTEM INC', '311626179', 'Health', '', 'Health organization with annual revenue of approximately $1498M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CENTRAL ELECTRIC POWER COOPERATIVE INC', '570299350', 'Other', '', 'Other organization with annual revenue of approximately $1494M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'NATURE CONSERVANCY', '530242652', 'Other', '', 'Other organization with annual revenue of approximately $1482M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ALTAMED HEALTH SERVICES CORP', '952810095', 'Health', '', 'Health organization with annual revenue of approximately $1480M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PHOENIX CHILDRENS HOSPITAL', '860422559', 'Health', '', 'Health organization with annual revenue of approximately $1480M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DIGNITY HEALTH MEDICAL FOUNDATION', '680220314', 'Health', '', 'Health organization with annual revenue of approximately $1480M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DEACONESS HOSPITAL INC', '350593390', 'Health', '', 'Health organization with annual revenue of approximately $1473M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MCHS HOSPITALS INC', '810977948', 'Health', '', 'Health organization with annual revenue of approximately $1462M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BAYLOR UNIVERSITY', '741159753', 'Education', '', 'Education organization with annual revenue of approximately $1462M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WESTERN GOVERNORS UNIVERSITY', '474365018', 'Education', '', 'Education organization with annual revenue of approximately $1462M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'RENAISSANCE CHARITABLE FOUNDATION INC', '352129262', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1459M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHP OF WASHINGTON', '911729710', 'Health', '', 'Health organization with annual revenue of approximately $1458M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MEDICA HEALTH PLANS', '411242261', 'Other', '', 'Other organization with annual revenue of approximately $1453M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THE GOVERNORS OF THE UNIVERSITY OF ALBERTA', '986001254', 'International', '', 'International organization with annual revenue of approximately $1452M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'RESEARCH FOUNDATION FOR THE STATE UNIVERSITY OF NEW YORK', '141368361', 'Education', '', 'Education organization with annual revenue of approximately $1443M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FORSYTH MEMORIAL HOSPITAL INC', '560928089', 'Health', '', 'Health organization with annual revenue of approximately $1442M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY OF WISCONSIN MEDICAL FOUNDATION INC', '391824445', 'Health', '', 'Health organization with annual revenue of approximately $1439M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FEDERATION INTERNATIONALE DE FOOTBALL ASSOCIATION', '980132529', 'Other', '', 'Other organization with annual revenue of approximately $1438M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SECURITY HEALTH PLAN OF WISCONSIN INC', '391572880', 'Other', '', 'Other organization with annual revenue of approximately $1438M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THE UNIVERSITY OF QUEENSLAND', '980127096', 'Other', '', 'Other organization with annual revenue of approximately $1438M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MOTHER FRANCES HOSPITAL REGIONAL HEALTH CARE CENTER', '750818167', 'Health', '', 'Health organization with annual revenue of approximately $1435M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHILDRENS HOSPITAL OF ORANGE COUNTY', '952321786', 'Health', '', 'Health organization with annual revenue of approximately $1431M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WILLIAM MARSH RICE UNIVERSITY', '741109620', 'Education', '', 'Education organization with annual revenue of approximately $1423M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MOUNT CARMEL HEALTH SYSTEM', '311439334', 'Other', '', 'Other organization with annual revenue of approximately $1416M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THE CARLE FOUNDATION HOSPITAL', '371119538', 'Health', '', 'Health organization with annual revenue of approximately $1415M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITE DE MONTREAL SUCCURSALE A QUEBEC', '237172320', 'Education', '', 'Education organization with annual revenue of approximately $1405M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'RESEARCH TRIANGLE INSTITUTE', '560686338', 'Research', '', 'Research organization with annual revenue of approximately $1403M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DREXEL UNIVERSITY', '231352630', 'Education', '', 'Education organization with annual revenue of approximately $1400M'
FROM users WHERE email = 'test@example.com';
