SELECT id, 'CHAN ZUCKERBERG BIOHUB INC', '811669175', 'Health', '', 'Health organization with annual revenue of approximately $1290M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PRIORITY HEALTH CHOICE INC', '320016523', 'Health', '', 'Health organization with annual revenue of approximately $1288M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'AMERICAN POSTAL WORKERS UNION', '520940594', 'Other', '', 'Other organization with annual revenue of approximately $1288M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DUKE HEALTH INTEGRATED PRACTICE INC', '862109896', 'Other', '', 'Other organization with annual revenue of approximately $1286M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'TEAMSTERS WESTERN REGION AND NEW JERSEY HEALTH CARE FUND', '866052021', 'Other', '', 'Other organization with annual revenue of approximately $1286M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'INDIANA UNIVERSITY HEALTH CARE ASSOCIATES INC', '351747218', 'Health', '', 'Health organization with annual revenue of approximately $1283M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LEGACY EMANUEL HOSPITAL & HEALTH CENTER', '930386823', 'Health', '', 'Health organization with annual revenue of approximately $1283M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'VIRGINIA MASON MEDICAL CENTER', '910565539', 'Health', '', 'Health organization with annual revenue of approximately $1277M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ASCENSION HEALTH-IS INC', '651257719', 'Other', '', 'Other organization with annual revenue of approximately $1274M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UOFL HEALTH-LOUISVILLE INC', '843178470', 'Health', '', 'Health organization with annual revenue of approximately $1274M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GROUP HEALTH INC', '410797853', 'Health', '', 'Health organization with annual revenue of approximately $1261M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'VILLAGE SENIOR SERVICES CORPORATION', '262006545', 'Health', '', 'Health organization with annual revenue of approximately $1261M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MCLEOD REGIONAL MEDICAL CENTER OF THE PEE DEE INC', '570370242', 'Health', '', 'Health organization with annual revenue of approximately $1253M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CITY UNIVERSITY CONSTRUCTION FUND', '132587538', 'Education', '', 'Education organization with annual revenue of approximately $1253M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SAINT THOMAS WEST HOSPITAL', '620347580', 'Health', '', 'Health organization with annual revenue of approximately $1250M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST CHARLES HEALTH SYSTEM INC', '930602940', 'Health', '', 'Health organization with annual revenue of approximately $1249M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHRISTUS HEALTH', '760590551', 'Health', '', 'Health organization with annual revenue of approximately $1242M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THE GOVERNORS OF THE UNIVERSITY OF CALGARY', '237067592', 'Other', '', 'Other organization with annual revenue of approximately $1241M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'COMMUNITY BEHAVORIAL HEALTH', '232766661', 'Health', '', 'Health organization with annual revenue of approximately $1240M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'INTERMOUNTAIN MEDICAL HOLDINGS NEVADA INC', '200160881', 'Health', '', 'Health organization with annual revenue of approximately $1238M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'TEXAS HEALTH HARRIS METHODIST HOSPITAL FORT WORTH', '756001743', 'Health', '', 'Health organization with annual revenue of approximately $1233M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ADVOCATE NORTH SIDE HEALTH NETWORK', '363196629', 'Health', '', 'Health organization with annual revenue of approximately $1232M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LAHEY CLINIC HOSPITAL INC', '042704686', 'Health', '', 'Health organization with annual revenue of approximately $1228M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CENTRAL IOWA HOSPITAL CORPORATION', '420680452', 'Health', '', 'Health organization with annual revenue of approximately $1227M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHRISTUS SANTA ROSA HEALTH CARE CORPORATION', '741109665', 'Health', '', 'Health organization with annual revenue of approximately $1225M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DRISCOLL CHILDRENS HEALTH PLAN', '742838488', 'Health', '', 'Health organization with annual revenue of approximately $1225M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PRESENCE CHICAGO HOSPITALS NETWORK', '362235165', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1225M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'INTEGRIS BAPTIST MEDICAL CENTER INC', '731034824', 'Health', '', 'Health organization with annual revenue of approximately $1223M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'VALLEY HEALTH SYSTEM', '800584319', 'Other', '', 'Other organization with annual revenue of approximately $1222M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CARESOURCE INDIANA INC', '320121856', 'Health', '', 'Health organization with annual revenue of approximately $1218M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'EDWARD W SPARROW HOSPITAL ASSOCIATION', '381360584', 'Health', '', 'Health organization with annual revenue of approximately $1211M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GENERAL ELECTRIC COMPANY INSURANCE PLAN TRUST CO V A DIAMANTE', '510169382', 'Other', '', 'Other organization with annual revenue of approximately $1210M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LINE CONSTRUCTION BENEFIT FUND', '366066988', 'Other', '', 'Other organization with annual revenue of approximately $1208M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'STRATACOR', '411852523', 'Other', '', 'Other organization with annual revenue of approximately $1205M'
