FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY HOSPITALS HEALTH SYSTEM INC', '900059117', 'Health', '', 'Health organization with annual revenue of approximately $5286M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CEDARS-SINAI MEDICAL CENTER', '951644600', 'Health', '', 'Health organization with annual revenue of approximately $5280M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SENTARA HEALTH PLANS', '541283337', 'Health', '', 'Health organization with annual revenue of approximately $5248M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'METROPLUS HEALTH PLAN INC', '134115686', 'Health', '', 'Health organization with annual revenue of approximately $5218M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WASHINGTON UNIVERSITY', '430653611', 'Education', '', 'Education organization with annual revenue of approximately $5204M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BOSTON MEDICAL CENTER HEALTH PLAN INC', '043373331', 'Health', '', 'Health organization with annual revenue of approximately $5196M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SUTTER BAY HOSPITALS', '940562680', 'Health', '', 'Health organization with annual revenue of approximately $5162M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'KAISER FOUNDATION HEALTH PLAN OF THE NORTHWEST', '930798039', 'Health', '', 'Health organization with annual revenue of approximately $5118M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'OHIOHEALTH CORPORATION GRANT RIVERSIDE DOCTORS DUBLIN MET', '314394942', 'Health', '', 'Health organization with annual revenue of approximately $5060M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MONTEFIORE MEDICAL CENTER', '131740114', 'Health', '', 'Health organization with annual revenue of approximately $5057M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FEEDING AMERICA', '363673599', 'Human Services', '', 'Human Services organization with annual revenue of approximately $5047M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ECMC GROUP INC', '411991995', 'Education', '', 'Education organization with annual revenue of approximately $5041M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CENTRAL STATES SOUTHEAST & SOUTHWEST AREAS HEALTH & WELFARE F', '362154936', 'Other', '', 'Other organization with annual revenue of approximately $5014M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SCAN HEALTH PLAN', '953858259', 'Health', '', 'Health organization with annual revenue of approximately $4939M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY OF CHICAGO', '362177139', 'Education', '', 'Education organization with annual revenue of approximately $4888M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SCRIPPS HEALTH', '951684089', 'Health', '', 'Health organization with annual revenue of approximately $4869M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ORLANDO HEALTH INC', '591726273', 'Health', '', 'Health organization with annual revenue of approximately $4827M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ADVANCED TECHNOLOGY INTERNATIONAL', '571067151', 'Research', '', 'Research organization with annual revenue of approximately $4825M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MERCY CARE', '860527381', 'Other', '', 'Other organization with annual revenue of approximately $4809M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FAIRVIEW HEALTH SERVICES', '410991680', 'Health', '', 'Health organization with annual revenue of approximately $4707M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SUTTER VALLEY HOSPITALS', '941156621', 'Health', '', 'Health organization with annual revenue of approximately $4658M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SELECTHEALTH INC', '870409820', 'Health', '', 'Health organization with annual revenue of approximately $4594M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ASTRAZENECA PATIENT ASSISTANCE ORGANIZATION', '562591004', 'Health', '', 'Health organization with annual revenue of approximately $4586M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'YALE NEW HAVEN HOSPITAL', '060646652', 'Health', '', 'Health organization with annual revenue of approximately $4571M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MULTICARE HEALTH SYSTEM', '911352172', 'Health', '', 'Health organization with annual revenue of approximately $4500M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'HENRY FORD HEALTH SYSTEM', '381357020', 'Health', '', 'Health organization with annual revenue of approximately $4495M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BLUE CARE NETWORK OF MICHIGAN', '382359234', 'Health', '', 'Health organization with annual revenue of approximately $4483M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DUKE UNIVERSITY', '560532129', 'Education', '', 'Education organization with annual revenue of approximately $4479M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BAPTIST HEALTHCARE SYSTEM INC', '610444707', 'Health', '', 'Health organization with annual revenue of approximately $4336M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'KAISER FOUNDATION HEALTH PLAN OF COLORADO', '840591617', 'Health', '', 'Health organization with annual revenue of approximately $4289M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ATLANTIC HEALTH SYSTEM INC', '651301877', 'Other', '', 'Other organization with annual revenue of approximately $4238M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'KAISER FOUNDATION HEALTH PLAN OF WASHINGTON', '910511770', 'Health', '', 'Health organization with annual revenue of approximately $4197M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'NORTHWESTERN UNIVERSITY', '362167817', 'Human Services', '', 'Human Services organization with annual revenue of approximately $4177M'
FROM users WHERE email = 'test@example.com';
