INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DELTA DENTAL OF WASHINGTON', '910621480', 'Health', '', 'Health organization with annual revenue of approximately $1755M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FALLON COMMUNITY HEALTH PLAN INC', '237442369', 'Health', '', 'Health organization with annual revenue of approximately $1751M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'THE QUEENS MEDICAL CENTER', '990073524', 'Health', '', 'Health organization with annual revenue of approximately $1751M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST JOSEPHS HOSPITAL INC', '590774199', 'Health', '', 'Health organization with annual revenue of approximately $1749M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'YORK HOSPITAL', '231352222', 'Health', '', 'Health organization with annual revenue of approximately $1749M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MAIN LINE HOSPITALS INC', '231352160', 'Health', '', 'Health organization with annual revenue of approximately $1746M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GEISINGER CLINIC', '236291113', 'Health', '', 'Health organization with annual revenue of approximately $1746M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'AARP', '951985500', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1741M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'RADY CHILDRENS HOSPITAL-SAN DIEGO', '951691313', 'Health', '', 'Health organization with annual revenue of approximately $1741M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'REX HOSPITAL INC', '561509260', 'Health', '', 'Health organization with annual revenue of approximately $1733M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHILDRENS HOSPITAL LOS ANGELES', '951690977', 'Health', '', 'Health organization with annual revenue of approximately $1730M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHILDRENS HOSPITAL', '530196580', 'Health', '', 'Health organization with annual revenue of approximately $1718M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WASHINGTON HOSPITAL CENTER CORPORATION', '521272129', 'Health', '', 'Health organization with annual revenue of approximately $1714M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'AVERA MCKENNAN', '460224743', 'Health', '', 'Health organization with annual revenue of approximately $1712M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'RWJBH CORPORATE SERVICES INC', '222405279', 'Health', '', 'Health organization with annual revenue of approximately $1706M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'TRUSTEES OF DARTMOUTH COLLEGE', '020222111', 'Education', '', 'Education organization with annual revenue of approximately $1704M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BAYADA HOME HEALTH CARE INC', '231943113', 'Health', '', 'Health organization with annual revenue of approximately $1698M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'KALEIDA HEALTH', '161533232', 'Health', '', 'Health organization with annual revenue of approximately $1688M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PIEDMONT HEALTHCARE INC', '580566213', 'Health', '', 'Health organization with annual revenue of approximately $1685M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'NEW YORK SOCIETY FOR THE RELIEF OF RUPTURED & CRIPPLED MAINTAINING', '131624135', 'Health', '', 'Health organization with annual revenue of approximately $1681M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHARLESTON AREA MEDICAL CENTER INC', '550526150', 'Health', '', 'Health organization with annual revenue of approximately $1678M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MEDSTAR-GEORGETOWN MEDICAL CENTER INC', '522218584', 'Health', '', 'Health organization with annual revenue of approximately $1675M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MEMORIAL SLOAN-KETTERING CANCER CENTER', '131924236', 'Health', '', 'Health organization with annual revenue of approximately $1670M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SACRED HEART HEALTH SYSTEM INC', '590634434', 'Health', '', 'Health organization with annual revenue of approximately $1658M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LOYOLA UNIVERSITY MEDICAL CENTER', '364015560', 'Health', '', 'Health organization with annual revenue of approximately $1650M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LEXINGTON HEALTH INC', '852276567', 'Health', '', 'Health organization with annual revenue of approximately $1647M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BROWN UNIVERSITY OF PROVIDENCE', '050258809', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1645M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WAKE FOREST UNIVERSITY HEALTH SCIENCES', '223849199', 'Education', '', 'Education organization with annual revenue of approximately $1642M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BOSTON COLLEGE TRUSTEES', '042103545', 'Education', '', 'Education organization with annual revenue of approximately $1638M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SCOTT AND WHITE HEALTH PLAN', '742052197', 'Other', '', 'Other organization with annual revenue of approximately $1632M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST LUKES ROOSEVELT HOSPITAL CENTER', '132997301', 'Health', '', 'Health organization with annual revenue of approximately $1628M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MEMORIAL HEALTH SYSTEM', '900756744', 'Other', '', 'Other organization with annual revenue of approximately $1627M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'LOUISIANA CHILDRENS MEDICAL CENTER', '943480131', 'Health', '', 'Health organization with annual revenue of approximately $1626M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
