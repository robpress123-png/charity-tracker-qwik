FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, '130 REGIONAL WATER SYPPLY CORPORATION', '813220497', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1204M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SOUTHCOAST HOSPITALS GROUP INC', '222592333', 'Health', '', 'Health organization with annual revenue of approximately $1203M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'MCLAREN HEALTH PLAN INC', '383252216', 'Health', '', 'Health organization with annual revenue of approximately $1202M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'TEXAS CHRISTIAN UNIVERSITY', '750827465', 'Education', '', 'Education organization with annual revenue of approximately $1198M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SSM HEALTH CARE CORPORATION', '466029223', 'Health', '', 'Health organization with annual revenue of approximately $1194M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FIRST HEALTH OF THE CAROLINAS INC', '561936354', 'Health', '', 'Health organization with annual revenue of approximately $1190M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DELTA ACCOUNT BASED MEDICAL TR', '753261600', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1190M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'DELTA DENTAL PLAN OF MICHIGAN', '381791480', 'Health', '', 'Health organization with annual revenue of approximately $1188M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'BANK OF AMERICA CHARITABLE GIFT FUND', '046010342', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1188M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CUMBERLAND COUNTY HOSPITAL SYSTEM INC', '560845796', 'Health', '', 'Health organization with annual revenue of approximately $1176M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'KROGER CO HEALTH AND WELFARE BENEFIT TR FOR COLLECTIVELY-BARGAI', '311444123', 'Other', '', 'Other organization with annual revenue of approximately $1174M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'NORTH CAROLINA ELECTRIC MEMBERSHIP CORPORATION', '560995910', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1171M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'GUNDERSEN LUTHERAN ADMINISTRATIVE SERVICES INC', '391606449', 'Health', '', 'Health organization with annual revenue of approximately $1171M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'IDEA PUBLIC SCHOOLS', '742948339', 'Education', '', 'Education organization with annual revenue of approximately $1170M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'COBB HOSPITAL', '580968382', 'Health', '', 'Health organization with annual revenue of approximately $1170M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'RENOWN REGIONAL MEDICAL CENTER', '880213754', 'Health', '', 'Health organization with annual revenue of approximately $1167M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'FLORIDA CLINICAL PRACTICE ASSOCIATION INC', '591680273', 'Other', '', 'Other organization with annual revenue of approximately $1164M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'UNIVERSITY OF ALABAMA HEALTH SERVICES FOUNDATION PC', '630649108', 'Health', '', 'Health organization with annual revenue of approximately $1157M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ST LUKES HOSPITAL OF KANSAS CITY', '440545297', 'Health', '', 'Health organization with annual revenue of approximately $1157M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ROCHESTER INSTITUTE OF TECHNOLOGY', '160743140', 'Education', '', 'Education organization with annual revenue of approximately $1155M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'VALLEY HOSPITAL INC', '221487307', 'Health', '', 'Health organization with annual revenue of approximately $1153M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ALLIANT CREDIT UNION', '366066772', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1150M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'PARKLAND COMMUNITY HEALTH PLAN INC', '752603847', 'Other', '', 'Other organization with annual revenue of approximately $1149M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SOUTHERN METHODIST UNIVERSITY', '750800689', 'Education', '', 'Education organization with annual revenue of approximately $1148M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SALEM HEALTH', '930579722', 'Health', '', 'Health organization with annual revenue of approximately $1141M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'KETTERING COLLEGE', '310621866', 'Health', '', 'Health organization with annual revenue of approximately $1140M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'WOODMEN OF THE WORLD LIFE INSURANCE SOCIETY', '470339250', 'Other', '', 'Other organization with annual revenue of approximately $1140M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CHILDRENS HEALTH CARE', '411754276', 'Health', '', 'Health organization with annual revenue of approximately $1138M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'SHANDS JACKSONVILLE MEDICAL CENTER INC', '592142859', 'Health', '', 'Health organization with annual revenue of approximately $1138M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'VIRTU-WEST JERSEY HEALTH SYSTEM INC', '210634532', 'Health', '', 'Health organization with annual revenue of approximately $1136M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'JEWISH COMMUNAL FUND', '237174183', 'Human Services', '', 'Human Services organization with annual revenue of approximately $1135M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'CAPITAL HEALTH SYSTEM INC', '223548695', 'Health', '', 'Health organization with annual revenue of approximately $1134M'
FROM users WHERE email = 'test@example.com';
INSERT OR IGNORE INTO charities (user_id, name, ein, category, website, description)
SELECT id, 'ELDERSERVE HEALTH INC', '800517818', 'Health', '', 'Health organization with annual revenue of approximately $1134M'
FROM users WHERE email = 'test@example.com';
