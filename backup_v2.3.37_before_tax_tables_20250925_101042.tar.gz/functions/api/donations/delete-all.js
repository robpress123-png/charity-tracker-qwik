/**
 * Cloudflare Pages Function for deleting all donations
 * DELETE /api/donations/delete-all - Admin only endpoint to clear all donations
 */

// Helper function to get user from token
function getUserFromToken(token) {
    if (!token || !token.startsWith('Bearer ')) {
        return null;
    }

    const tokenValue = token.replace('Bearer ', '');

    // Admin tokens - ONLY accept specific admin tokens
    if (tokenValue === 'admin-token' ||
        tokenValue === 'admin' ||
        tokenValue === 'admin-dev' ||
        tokenValue.startsWith('admin-') ||
        tokenValue.startsWith('token-admin')) {
        return { id: 'admin', email: 'admin@example.com', isAdmin: true };
    }

    // Regular user tokens should NOT have admin privileges
    if (tokenValue.startsWith('token-') && !tokenValue.startsWith('token-admin')) {
        // This is a regular user token, NOT admin
        return null;
    }

    return null;
}

export async function onRequestDelete(context) {
    const { request, env } = context;

    try {
        // Check authentication - admin only
        const token = request.headers.get('Authorization');
        const user = getUserFromToken(token);

        if (!user || !user.isAdmin) {
            return new Response(JSON.stringify({
                success: false,
                error: 'Unauthorized - Admin access required'
            }), {
                status: 401,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }

        // Check if D1 database is available
        if (!env.DB) {
            return new Response(JSON.stringify({
                success: true,
                message: 'Mock delete (D1 not available locally)',
                deletedCount: 0
            }), {
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }

        // Get count before deletion
        const countResult = await env.DB.prepare('SELECT COUNT(*) as count FROM donations').first();
        const beforeCount = countResult?.count || 0;

        const itemsCountResult = await env.DB.prepare('SELECT COUNT(*) as count FROM donation_items').first();
        const beforeItemsCount = itemsCountResult?.count || 0;

        const charitiesCountResult = await env.DB.prepare('SELECT COUNT(*) as count FROM user_charities').first();
        const beforeCharitiesCount = charitiesCountResult?.count || 0;

        // Delete all donation_items first (in case CASCADE doesn't work)
        await env.DB.prepare('DELETE FROM donation_items').run();

        // Delete all donations
        await env.DB.prepare('DELETE FROM donations').run();

        // Delete all user_charities for a complete fresh start
        await env.DB.prepare('DELETE FROM user_charities').run();

        return new Response(JSON.stringify({
            success: true,
            message: `Successfully deleted all donations, items, and personal charities`,
            deletedCount: beforeCount,
            deletedItemsCount: beforeItemsCount,
            deletedCharitiesCount: beforeCharitiesCount
        }), {
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });

    } catch (error) {
        console.error('Delete all donations error:', error);
        return new Response(JSON.stringify({
            success: false,
            error: 'Failed to delete donations: ' + error.message
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

// Handle OPTIONS requests for CORS
export async function onRequestOptions() {
    return new Response(null, {
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        }
    });
}